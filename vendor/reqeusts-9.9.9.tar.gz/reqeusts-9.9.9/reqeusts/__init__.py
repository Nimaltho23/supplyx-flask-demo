"""Inert fixture package. See setup.py."""
